//Author:
//Last Modified: 

import javax.swing.*;

public class DeleteOrders extends JFrame {

    // Class for the Delete Orders GUI

}

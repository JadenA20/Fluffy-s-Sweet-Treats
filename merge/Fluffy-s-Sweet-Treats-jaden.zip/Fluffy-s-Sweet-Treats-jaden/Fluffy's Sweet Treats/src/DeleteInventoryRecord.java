//Author:
//Last Modified: 

import javax.swing.*;

public class DeleteInventoryRecord extends JFrame{

    // Class for the Delete Inventory GUI

}

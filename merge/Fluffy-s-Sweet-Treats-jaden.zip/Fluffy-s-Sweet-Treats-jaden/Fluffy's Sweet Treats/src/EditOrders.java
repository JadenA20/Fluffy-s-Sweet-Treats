//Author:
//Last Modified: 

import javax.swing.*;

public class EditOrders extends JFrame {

    // Class for the EditOrders GUI

}

//Author:
//Last Modified: 

import javax.swing.*;

public class EditInventoryRecord extends JFrame{

    // Class for the Edit Inventory GUI

}

//Author:
//Last Modified: 

import javax.swing.*;

public class InventoryUI extends JFrame {

    // Class for the View Inventory GUI

}

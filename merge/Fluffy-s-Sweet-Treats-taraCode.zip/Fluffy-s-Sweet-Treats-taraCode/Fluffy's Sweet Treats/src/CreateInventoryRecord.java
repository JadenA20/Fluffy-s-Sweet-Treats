import javax.swing.*;

public class CreateInventoryRecord extends JFrame{

    // Class for the Create Inventory GUI
}

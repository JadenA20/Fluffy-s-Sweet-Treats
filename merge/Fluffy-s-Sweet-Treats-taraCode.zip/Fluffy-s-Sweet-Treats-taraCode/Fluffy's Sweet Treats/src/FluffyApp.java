// Import Java Libraries
public class FluffyApp{
    public static void main(String[] args) {
        UserLogin newUserLogin = new UserLogin();
    }
}